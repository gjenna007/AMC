function a=gummer(orig,getek)
%blauwe pixels worden gecorrigeerd
s=size(orig)
a=getek;
for ver=1:s(1)
   for hor=1:s(2)
      if getek(ver,hor,1)<getek(ver,hor,3)
         a(ver,hor,1)=orig(ver,hor,1);
         a(ver,hor,2)=orig(ver,hor,2);
         a(ver,hor,3)=orig(ver,hor,3);
      end
      if getek(ver,hor,1)>getek(ver,hor,3)
         a(ver,hor,:)=1;
      end
   end
end

